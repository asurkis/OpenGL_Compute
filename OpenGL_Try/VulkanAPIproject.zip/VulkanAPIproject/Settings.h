#pragma once

#include "stdafx.h"

#define VSYNC (true)
#define WIDTH (1366)
#define HEIGHT (768)
