#pragma once
#include "stdafx.h"

class Vertex
{
public:
	Vertex(glm::vec2 _vertexPosition);
	~Vertex();

	glm::vec2 vertexPosition;

	static VkVertexInputBindingDescription getVkVertexInputBindingDescription();
	static std::vector<VkVertexInputAttributeDescription> getVkVertexInputAttributeDescription();
};
