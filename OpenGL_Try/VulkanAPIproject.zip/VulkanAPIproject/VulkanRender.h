#pragma once

#include "stdafx.h"

struct VRQueueUnit {
	unsigned int  iQueueFamily;
	VkQueue       hQueue;
	VkCommandPool hCommandPool;
};

class VulkanRender
{
public:
    VulkanRender();
	~VulkanRender();

	void draw();
    bool init(HINSTANCE hInstance, HWND hWnd);
private:
	std::vector<const char*>
		             requiredInstanceExtensions_;
	std::vector<const char*>
					 requiredDeviceExtentions_;
    std::vector<const char*> requiredLayers_;

	VkDevice         device_;
	VkInstance       instance_;
    VkDebugUtilsMessengerEXT debugMessenger_;
	VkSurfaceKHR     surfaceKhr_;
	VkPhysicalDevice gpu_;
	VRQueueUnit      queue_;
	VkSwapchainKHR   swapchainKhr_;

	VkPhysicalDeviceFeatures
		             physicalDeviceFeatures;

	VkPhysicalDeviceMemoryProperties
					 physicalDeviceMemoryProperties;

	std::vector<VkImage>
					 swapchainImages_;

	std::vector<VkCommandBuffer>
					 commandBuffers_;

	VkShaderModule   shaderModuleVert;
	VkShaderModule   shaderModuleFrag;
	VkShaderModule   shaderModuleComp;

	VkViewport       viewport;
	VkRect2D         scissor;

	VkPipelineLayout pipelineLayout;
	VkRenderPass     renderPass;
	VkPipeline       graphicsPipeline;
	VkPipeline       computePipeline;

	VkSemaphore      semaphoreImageAvailable;
	VkSemaphore      semaphoreRenderingFinished;

	VkBuffer         vertexBuffer;
	VkDeviceMemory   vertexBufferDeviceMemory;

	VkPipelineCache  pipelineCache;

	std::vector<VkFramebuffer>
		             frameBuffers;

	std::vector<VkImageMemoryBarrier>
					 imageMemoryBarrierPresentToClear;

	std::vector<VkImageMemoryBarrier>
					 imageMemoryBarrierClearToPresent;

	std::vector<VkImageView>
					 imageViews_;

	VkBufferCreateInfo
		             bufferCreateInfo{};

	void createShaderModule(const std::vector<char>& code, VkShaderModule* shaderModeule);

	uint32_t findMemoryTypeIndex(uint32_t typeFilter, VkMemoryPropertyFlags properties);
};
