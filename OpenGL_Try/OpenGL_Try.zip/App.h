#pragma once

#include "ShaderProgram.h"

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>

class App
{
    GLFWwindow *window;
    GLuint vertexArrayId;
    GLuint bufferIdx[2];

    ShaderProgram *computeProgram;
    ShaderProgram *shaderProgram;

    void init();

    void initGLFW();
    void initGLEW();
    void initBuffers();
    void initShaders();

    float random();

    App(const App &) {}

public:
    App();
    ~App();
    void run();

    inline GLFWwindow *getWindow() const { return window; }

    static const int WINDOW_WIDTH = 800;
    static const int WINDOW_HEIGHT = 800;
    static const int PARTICLE_COUNT = 1 << 16;
};

extern App app;
