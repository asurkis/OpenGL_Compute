#include "stdafx.h"

std::vector<glm::vec2> verticesPositions(750);

std::vector<char> readFile(const std::string &filename) {
	std::ifstream file(filename, std::ios::binary | std::ios::ate);

	if (file) {
		size_t fileSize = (size_t)file.tellg();
		std::vector<char> fileBuffer(fileSize);
		file.seekg(0);
		file.read(fileBuffer.data(), fileSize);

		file.close();

		return fileBuffer;
	}
	else
		throw std::runtime_error("error reading file");
}

void VulkanRender::createShaderModule(const std::vector<char>& code, VkShaderModule* shaderModeule) {
	VkShaderModuleCreateInfo shaderModuleCreateInfo{};

	shaderModuleCreateInfo.sType = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO;
	shaderModuleCreateInfo.pNext = nullptr;
	shaderModuleCreateInfo.flags = 0;
	shaderModuleCreateInfo.codeSize = code.size();
	shaderModuleCreateInfo.pCode = (uint32_t*)code.data();

	if (vkCreateShaderModule(this->device_, &shaderModuleCreateInfo, nullptr, shaderModeule) != VK_SUCCESS)
		throw std::runtime_error("error creating shader module");
}

uint32_t VulkanRender::findMemoryTypeIndex(uint32_t typeFilter, VkMemoryPropertyFlags properties) {
	for (uint32_t i = 0; i < physicalDeviceMemoryProperties.memoryTypeCount; i++)
		if ((typeFilter & (1 << i)) && ((physicalDeviceMemoryProperties.memoryTypes[i].propertyFlags & properties) == properties))
			return i;

	throw std::runtime_error("SUKAA BL'YAT'");
}

VulkanRender::VulkanRender():
    instance_     (VK_NULL_HANDLE),
    surfaceKhr_   (VK_NULL_HANDLE),
    gpu_          (VK_NULL_HANDLE),
    device_       (VK_NULL_HANDLE),
    swapchainKhr_ (VK_NULL_HANDLE)
{}

VKAPI_ATTR VkBool32 VKAPI_CALL vulkanDebugCallback(VkDebugUtilsMessageSeverityFlagBitsEXT messageSeverity,
                                                   VkDebugUtilsMessageTypeFlagsEXT messageType,
                                                   const VkDebugUtilsMessengerCallbackDataEXT *pCallbackData,
                                                   void *pUserData)
{
    fprintf(stderr, "[vulkan] %s\n", pCallbackData->pMessage);
    fflush(stderr);
    return VK_FALSE;
}

bool VulkanRender::init(HINSTANCE hInstance, HWND hWnd)
{
    for (auto &v: verticesPositions)
        v = glm::vec2(-1 + 2 * (float) rand() / RAND_MAX, -1 + 2 * (float) rand() / RAND_MAX);
	// verticesPositions[0] = glm::vec2(0.5f, 0.5f);
	// verticesPositions[1] = glm::vec2(-0.5f, 0.5f);
	// verticesPositions[2] = glm::vec2(0.5f, -0.5f);

	requiredInstanceExtensions_ = {
        VK_KHR_SURFACE_EXTENSION_NAME,
        VK_KHR_WIN32_SURFACE_EXTENSION_NAME,
        VK_EXT_DEBUG_UTILS_EXTENSION_NAME
    };
	requiredDeviceExtentions_   = { VK_KHR_SWAPCHAIN_EXTENSION_NAME };
    requiredLayers_ = { "VK_LAYER_LUNARG_standard_validation" };

	VkApplicationInfo applicationInfo{};
	applicationInfo.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
	applicationInfo.apiVersion = VK_API_VERSION_1_1;

	VkInstanceCreateInfo iCreateInfo{};
	iCreateInfo.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
	iCreateInfo.pApplicationInfo = &applicationInfo;
	iCreateInfo.enabledExtensionCount = requiredInstanceExtensions_.size();
	iCreateInfo.ppEnabledExtensionNames = requiredInstanceExtensions_.data();
    iCreateInfo.enabledLayerCount = requiredLayers_.size();
    iCreateInfo.ppEnabledLayerNames = requiredLayers_.data();

	if (vkCreateInstance(&iCreateInfo, nullptr, &instance_) != VK_SUCCESS)
		throw std::runtime_error("Error creating VkInstance");

    VkDebugUtilsMessengerCreateInfoEXT debugMessengerCreateInfo {};
    debugMessengerCreateInfo.sType = VK_STRUCTURE_TYPE_DEBUG_UTILS_MESSENGER_CREATE_INFO_EXT;
    debugMessengerCreateInfo.messageSeverity = VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT;
    debugMessengerCreateInfo.messageType = 0x7;
    debugMessengerCreateInfo.pfnUserCallback = vulkanDebugCallback;
    debugMessengerCreateInfo.pUserData = NULL;

    auto createDebugMessengerFunc = (PFN_vkCreateDebugUtilsMessengerEXT) vkGetInstanceProcAddr(instance_, "vkCreateDebugUtilsMessengerEXT");
    assert(createDebugMessengerFunc != NULL);
    assert(VK_SUCCESS == createDebugMessengerFunc(instance_, &debugMessengerCreateInfo, NULL, &debugMessenger_));

	VkWin32SurfaceCreateInfoKHR win32SurfaceCreateInfoKhr{};
	win32SurfaceCreateInfoKhr.sType = VK_STRUCTURE_TYPE_WIN32_SURFACE_CREATE_INFO_KHR;
	win32SurfaceCreateInfoKhr.hinstance = hInstance;
	win32SurfaceCreateInfoKhr.hwnd = hWnd;

	PFN_vkCreateWin32SurfaceKHR vkCreateWin32SurfaceKHR = (PFN_vkCreateWin32SurfaceKHR)vkGetInstanceProcAddr(instance_, "vkCreateWin32SurfaceKHR");
	if (vkCreateWin32SurfaceKHR(instance_, &win32SurfaceCreateInfoKhr, nullptr, &surfaceKhr_) != VK_SUCCESS)
		throw std::runtime_error("Error creating Win32SurfaceKHR");

	unsigned int nPhysicalDevices = 0;
	vkEnumeratePhysicalDevices(instance_, &nPhysicalDevices, nullptr);

	std::vector<VkPhysicalDevice> allPhysicalDevices(nPhysicalDevices);
	vkEnumeratePhysicalDevices(instance_, &nPhysicalDevices, allPhysicalDevices.data());

	while (gpu_ == VK_NULL_HANDLE) {
		for (const VkPhysicalDevice& currentPhysicalDevice : allPhysicalDevices) {
			unsigned int nQueueFamilies = 0;
			vkGetPhysicalDeviceQueueFamilyProperties(currentPhysicalDevice, &nQueueFamilies, nullptr);

			std::vector<VkQueueFamilyProperties> allQueueFamilies(nQueueFamilies);
			vkGetPhysicalDeviceQueueFamilyProperties(currentPhysicalDevice, &nQueueFamilies, allQueueFamilies.data());

			int iSelectedQueueFamily = -1;
			for (unsigned int i = 0; i < allQueueFamilies.size(); i++) {
				VkBool32 presentationSupported = VK_FALSE;
				vkGetPhysicalDeviceSurfaceSupportKHR(currentPhysicalDevice, i, surfaceKhr_, &presentationSupported);;

				if (presentationSupported && allQueueFamilies.data()[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) {
					iSelectedQueueFamily = i;
					break;
				}
			}

			if (iSelectedQueueFamily != -1) {
				VkPhysicalDeviceProperties physicleDeviceProperties{};
				vkGetPhysicalDeviceProperties(currentPhysicalDevice, &physicleDeviceProperties);

				bool bGpuPicked = false;

				switch (MessageBoxA(hWnd, physicleDeviceProperties.deviceName, "Use this device?", MB_YESNOCANCEL))
				{
				case IDYES:
					gpu_ = currentPhysicalDevice;
					queue_.iQueueFamily = iSelectedQueueFamily;

					bGpuPicked = true;
					break;
				case IDNO:
					break;
				case IDCANCEL:
					return false;
				}

				if (bGpuPicked)
					break;
			}
		}
	}

	vkGetPhysicalDeviceFeatures(gpu_, &physicalDeviceFeatures);

	vkGetPhysicalDeviceMemoryProperties(gpu_, &physicalDeviceMemoryProperties);

	float queuePriority[]{ 1.0f };
	VkDeviceQueueCreateInfo deviceQueueCreateInfo{};
	deviceQueueCreateInfo.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
	deviceQueueCreateInfo.queueFamilyIndex = queue_.iQueueFamily;
	deviceQueueCreateInfo.queueCount = 1;
	deviceQueueCreateInfo.pQueuePriorities = queuePriority;

	VkDeviceCreateInfo deviceCreateInfo{};
	deviceCreateInfo.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
	deviceCreateInfo.queueCreateInfoCount = 1;
	deviceCreateInfo.pQueueCreateInfos = &deviceQueueCreateInfo;
	deviceCreateInfo.enabledExtensionCount = (unsigned int)requiredDeviceExtentions_.size();
	deviceCreateInfo.ppEnabledExtensionNames = requiredDeviceExtentions_.data();
    deviceCreateInfo.enabledLayerCount = requiredLayers_.size();
    deviceCreateInfo.ppEnabledLayerNames = requiredLayers_.data();

	if (vkCreateDevice(gpu_, &deviceCreateInfo, nullptr, &device_) != VK_SUCCESS)
		throw std::runtime_error("Error creating device");

	vkGetDeviceQueue(device_, queue_.iQueueFamily, 0, &queue_.hQueue);

	VkSurfaceFormatKHR surfaceFormatKhr{};

	unsigned int uSurfaceFormats = 0;
	vkGetPhysicalDeviceSurfaceFormatsKHR(gpu_, surfaceKhr_, &uSurfaceFormats, nullptr);

	std::vector<VkSurfaceFormatKHR> allSurfaceFormats(uSurfaceFormats);
	vkGetPhysicalDeviceSurfaceFormatsKHR(gpu_, surfaceKhr_, &uSurfaceFormats, allSurfaceFormats.data());

	for (const VkSurfaceFormatKHR& currentSurfaceFormat : allSurfaceFormats) {
		if (currentSurfaceFormat.format == VK_FORMAT_B8G8R8A8_UNORM && currentSurfaceFormat.colorSpace == VK_COLORSPACE_SRGB_NONLINEAR_KHR)
			surfaceFormatKhr = currentSurfaceFormat;
	}

	if (!surfaceFormatKhr.format)
		surfaceFormatKhr = allSurfaceFormats[0];

	VkPresentModeKHR presentModeKhr{};

	presentModeKhr = VK_PRESENT_MODE_IMMEDIATE_KHR;

	if (VSYNC) {
		unsigned int nPresentModes = 0;
		vkGetPhysicalDeviceSurfacePresentModesKHR(gpu_, surfaceKhr_, &nPresentModes, nullptr);

		std::vector<VkPresentModeKHR> allPresentModes(nPresentModes);
		vkGetPhysicalDeviceSurfacePresentModesKHR(gpu_, surfaceKhr_, &nPresentModes, allPresentModes.data());

		for (const VkPresentModeKHR& currentPresentMode : allPresentModes) {
			if (currentPresentMode == VK_PRESENT_MODE_MAILBOX_KHR)
				presentModeKhr = currentPresentMode;
		}

		if (presentModeKhr == VK_PRESENT_MODE_IMMEDIATE_KHR)
			presentModeKhr = VK_PRESENT_MODE_FIFO_KHR;
	}

	switch (presentModeKhr)
	{
	case VK_PRESENT_MODE_MAILBOX_KHR:
		MessageBoxA(hWnd, "VK_PRESENT_MODE_MAILBOX_KHR", "presentModeKhr", 0);
		break;
	case VK_PRESENT_MODE_IMMEDIATE_KHR:
		MessageBoxA(hWnd, "VK_PRESENT_MODE_IMMEDIATE_KHR", "presentModeKhr", 0);
		break;
	case VK_PRESENT_MODE_FIFO_KHR:
		MessageBoxA(hWnd, "VK_PRESENT_MODE_FIFO_KHR", "presentModeKhr", 0);
		break;
	default:
		MessageBoxA(hWnd, "Error detecting present mdoe", "presentModeKhr", 0);
		break;
	}

	VkSurfaceCapabilitiesKHR surfaceCapabilitiesKhr{};
	vkGetPhysicalDeviceSurfaceCapabilitiesKHR(gpu_, surfaceKhr_, &surfaceCapabilitiesKhr);

	VkSwapchainCreateInfoKHR swapchainCreateInfoKhr{};
	swapchainCreateInfoKhr.sType = VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR;
	swapchainCreateInfoKhr.surface = surfaceKhr_;
	swapchainCreateInfoKhr.minImageCount = surfaceCapabilitiesKhr.maxImageCount < 3 ? surfaceCapabilitiesKhr.maxImageCount : 3;
	swapchainCreateInfoKhr.imageFormat = surfaceFormatKhr.format;
	swapchainCreateInfoKhr.imageColorSpace = surfaceFormatKhr.colorSpace;
	swapchainCreateInfoKhr.imageExtent = surfaceCapabilitiesKhr.currentExtent;
	swapchainCreateInfoKhr.imageArrayLayers = 1;
	swapchainCreateInfoKhr.imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
	swapchainCreateInfoKhr.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE;
	swapchainCreateInfoKhr.preTransform = surfaceCapabilitiesKhr.currentTransform;
	swapchainCreateInfoKhr.compositeAlpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
	swapchainCreateInfoKhr.presentMode = presentModeKhr;
	swapchainCreateInfoKhr.clipped = VK_TRUE;
	swapchainCreateInfoKhr.oldSwapchain = VK_NULL_HANDLE;

	if (vkCreateSwapchainKHR(device_, &swapchainCreateInfoKhr, nullptr, &swapchainKhr_) != VK_SUCCESS)
		throw std::runtime_error("Error creating swapchain");

	unsigned int nImages = 0;
	vkGetSwapchainImagesKHR(device_, swapchainKhr_, &nImages, nullptr);

	swapchainImages_.resize(nImages);
	vkGetSwapchainImagesKHR(device_, swapchainKhr_, &nImages, swapchainImages_.data());

	imageViews_.resize(swapchainImages_.size());

	for (unsigned int i = 0; i < swapchainImages_.size(); i++) {
		VkImageViewCreateInfo imageViewCreateInfo{};
		imageViewCreateInfo.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
		imageViewCreateInfo.pNext = nullptr;
		imageViewCreateInfo.flags = 0;
		imageViewCreateInfo.image = swapchainImages_.data()[i];
		imageViewCreateInfo.viewType = VK_IMAGE_VIEW_TYPE_2D;
		imageViewCreateInfo.format = surfaceFormatKhr.format;
		imageViewCreateInfo.components.r = VK_COMPONENT_SWIZZLE_IDENTITY;
		imageViewCreateInfo.components.g = VK_COMPONENT_SWIZZLE_IDENTITY;
		imageViewCreateInfo.components.b = VK_COMPONENT_SWIZZLE_IDENTITY;
		imageViewCreateInfo.components.a = VK_COMPONENT_SWIZZLE_IDENTITY;
		imageViewCreateInfo.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
		imageViewCreateInfo.subresourceRange.baseMipLevel = 0;
		imageViewCreateInfo.subresourceRange.levelCount = 1;
		imageViewCreateInfo.subresourceRange.baseArrayLayer = 0;
		imageViewCreateInfo.subresourceRange.layerCount = 1;

		if (vkCreateImageView(device_, &imageViewCreateInfo, nullptr, &imageViews_.data()[i]) != VK_SUCCESS)
			throw std::runtime_error("Error creating image views");
	}

	auto shaderCodeVert = readFile("vert.spv");
	auto shaderCodeFrag = readFile("frag.spv");
	auto shaderCodeComp = readFile("comp.spv");

	this->createShaderModule(shaderCodeVert, &shaderModuleVert);
	this->createShaderModule(shaderCodeFrag, &shaderModuleFrag);
	this->createShaderModule(shaderCodeComp, &shaderModuleComp);


	VkPipelineShaderStageCreateInfo  pipelineShaderStageCreateInfoVert{};

	pipelineShaderStageCreateInfoVert.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
	pipelineShaderStageCreateInfoVert.pNext = nullptr;
	pipelineShaderStageCreateInfoVert.flags = 0;
	pipelineShaderStageCreateInfoVert.stage = VK_SHADER_STAGE_VERTEX_BIT;
	pipelineShaderStageCreateInfoVert.module = shaderModuleVert;
	pipelineShaderStageCreateInfoVert.pName = "main";
	pipelineShaderStageCreateInfoVert.pSpecializationInfo = nullptr;

	VkPipelineShaderStageCreateInfo  pipelineShaderStageCreateInfoFrag{};

	pipelineShaderStageCreateInfoFrag.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
	pipelineShaderStageCreateInfoFrag.pNext = nullptr;
	pipelineShaderStageCreateInfoFrag.flags = 0;
	pipelineShaderStageCreateInfoFrag.stage = VK_SHADER_STAGE_FRAGMENT_BIT;
	pipelineShaderStageCreateInfoFrag.module = shaderModuleFrag;
	pipelineShaderStageCreateInfoFrag.pName = "main";
	pipelineShaderStageCreateInfoFrag.pSpecializationInfo = nullptr;

	VkPipelineShaderStageCreateInfo shaderStagesInfo[] = {
		pipelineShaderStageCreateInfoVert,
		pipelineShaderStageCreateInfoFrag
	};

	VkPipelineShaderStageCreateInfo  pipelineShaderStageCreateInfoComp{};

	pipelineShaderStageCreateInfoComp.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
	pipelineShaderStageCreateInfoComp.pNext = nullptr;
	pipelineShaderStageCreateInfoComp.flags = 0;
	pipelineShaderStageCreateInfoComp.stage = VK_SHADER_STAGE_COMPUTE_BIT;
	pipelineShaderStageCreateInfoComp.module = shaderModuleComp;
	pipelineShaderStageCreateInfoComp.pName = "main";
	pipelineShaderStageCreateInfoComp.pSpecializationInfo = nullptr;

	VkVertexInputBindingDescription vertexInputBindingDescription = Vertex::getVkVertexInputBindingDescription();

	std::vector<VkVertexInputAttributeDescription> vertexInputAttributeDescription = Vertex::getVkVertexInputAttributeDescription();

	VkPipelineVertexInputStateCreateInfo piplineVertexInputStageCreateInfo{};

	piplineVertexInputStageCreateInfo.sType = VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO;
	piplineVertexInputStageCreateInfo.pNext = nullptr;
	piplineVertexInputStageCreateInfo.flags = 0;
	piplineVertexInputStageCreateInfo.vertexBindingDescriptionCount = 1;
	piplineVertexInputStageCreateInfo.pVertexBindingDescriptions = &vertexInputBindingDescription;
	piplineVertexInputStageCreateInfo.vertexAttributeDescriptionCount = vertexInputAttributeDescription.size();
	piplineVertexInputStageCreateInfo.pVertexAttributeDescriptions = vertexInputAttributeDescription.data();

	bufferCreateInfo.sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
	bufferCreateInfo.pNext = nullptr;
	bufferCreateInfo.flags = 0;
	//bufferCreateInfo.queueFamilyIndexCount = 1;
	bufferCreateInfo.queueFamilyIndexCount = 0;
	//bufferCreateInfo.pQueueFamilyIndices = &queue_.iQueueFamily;
	bufferCreateInfo.pQueueFamilyIndices = nullptr;
	bufferCreateInfo.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
	bufferCreateInfo.size = sizeof(Vertex) * verticesPositions.size();
	bufferCreateInfo.usage = VK_BUFFER_USAGE_VERTEX_BUFFER_BIT | VK_BUFFER_USAGE_STORAGE_BUFFER_BIT;

	if (vkCreateBuffer(device_, &bufferCreateInfo, nullptr, &vertexBuffer) != VK_SUCCESS)
		throw std::runtime_error("error creating buffer");

	VkMemoryRequirements memoryRequirements;

	vkGetBufferMemoryRequirements(device_, vertexBuffer, &memoryRequirements);

	VkMemoryAllocateInfo memoryAllocateInfo{};

	memoryAllocateInfo.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
	memoryAllocateInfo.pNext = nullptr;
	memoryAllocateInfo.allocationSize = memoryRequirements.size;
	memoryAllocateInfo.memoryTypeIndex = this->findMemoryTypeIndex(memoryRequirements.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);

	if (vkAllocateMemory(device_, &memoryAllocateInfo, nullptr, &vertexBufferDeviceMemory) != VK_SUCCESS)
		throw std::runtime_error("lol kek anton cheburek");

	vkBindBufferMemory(device_, vertexBuffer, vertexBufferDeviceMemory, 0);

	void* rawData;
	vkMapMemory(device_, vertexBufferDeviceMemory, 0, bufferCreateInfo.size, 0, &rawData);
	memcpy(rawData, verticesPositions.data(), bufferCreateInfo.size);
	vkUnmapMemory(device_, vertexBufferDeviceMemory);

	VkPipelineInputAssemblyStateCreateInfo piplineInputAssamblyStateInfo{};

	piplineInputAssamblyStateInfo.sType = VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO;
	piplineInputAssamblyStateInfo.pNext = nullptr;
	piplineInputAssamblyStateInfo.flags = 0;
	piplineInputAssamblyStateInfo.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_FAN;
	//piplineInputAssamblyStateInfo.topology = VK_PRIMITIVE_TOPOLOGY_POINT_LIST;
	piplineInputAssamblyStateInfo.primitiveRestartEnable = VK_FALSE;

	viewport.x = 0.0f;
	viewport.y = 0.0f;

	viewport.width  = WIDTH - 15;
	viewport.height = HEIGHT - 39;

	viewport.minDepth = 0.0f;
	viewport.maxDepth = 1.0f;

	scissor.offset = { (int32_t )viewport.x    , (int32_t )viewport.y      };
	scissor.extent = { (uint32_t)viewport.width, (uint32_t)viewport.height };

	VkPipelineViewportStateCreateInfo pipelineViewpotrStateCreateInfo{};

	pipelineViewpotrStateCreateInfo.sType = VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO;
	pipelineViewpotrStateCreateInfo.pNext = nullptr;
	pipelineViewpotrStateCreateInfo.flags = 0;
	pipelineViewpotrStateCreateInfo.viewportCount = 1;
	pipelineViewpotrStateCreateInfo.pViewports = &viewport;
	pipelineViewpotrStateCreateInfo.scissorCount = 1;
	pipelineViewpotrStateCreateInfo.pScissors = &scissor;

	VkPipelineRasterizationStateCreateInfo pipelineRasterizationStateCreateInfo{};

	pipelineRasterizationStateCreateInfo.sType = VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO;
	pipelineRasterizationStateCreateInfo.pNext = nullptr;
	pipelineRasterizationStateCreateInfo.flags = 0;
	pipelineRasterizationStateCreateInfo.depthClampEnable = VK_FALSE;
	pipelineRasterizationStateCreateInfo.rasterizerDiscardEnable = VK_FALSE;
	pipelineRasterizationStateCreateInfo.polygonMode = VK_POLYGON_MODE_FILL;
	pipelineRasterizationStateCreateInfo.cullMode = VK_CULL_MODE_BACK_BIT;
	pipelineRasterizationStateCreateInfo.frontFace = VK_FRONT_FACE_CLOCKWISE;
	pipelineRasterizationStateCreateInfo.depthBiasEnable = VK_FALSE;
	pipelineRasterizationStateCreateInfo.depthBiasConstantFactor = 0.0f;
	pipelineRasterizationStateCreateInfo.depthBiasClamp = 0.0f;
	pipelineRasterizationStateCreateInfo.depthBiasSlopeFactor = 0.0f;
	pipelineRasterizationStateCreateInfo.lineWidth = 1.0f;

	VkPipelineMultisampleStateCreateInfo pipelineMultisampleStateCreateInfo{};

	pipelineMultisampleStateCreateInfo.sType = VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO;
	pipelineMultisampleStateCreateInfo.pNext = nullptr;
	pipelineMultisampleStateCreateInfo.flags = 0;
	pipelineMultisampleStateCreateInfo.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;
	pipelineMultisampleStateCreateInfo.sampleShadingEnable = VK_FALSE;
	pipelineMultisampleStateCreateInfo.minSampleShading = 1.0f;
	pipelineMultisampleStateCreateInfo.pSampleMask = nullptr;
	pipelineMultisampleStateCreateInfo.alphaToCoverageEnable = VK_FALSE;
	pipelineMultisampleStateCreateInfo.alphaToOneEnable = VK_FALSE;

	VkPipelineColorBlendAttachmentState pipelineColorBlendAttachmentState;

	pipelineColorBlendAttachmentState.blendEnable = VK_TRUE;
	pipelineColorBlendAttachmentState.srcColorBlendFactor = VK_BLEND_FACTOR_SRC_ALPHA;
	pipelineColorBlendAttachmentState.dstColorBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;
	pipelineColorBlendAttachmentState.colorBlendOp = VK_BLEND_OP_ADD;
	pipelineColorBlendAttachmentState.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE;
	pipelineColorBlendAttachmentState.dstAlphaBlendFactor = VK_BLEND_FACTOR_ZERO;
	pipelineColorBlendAttachmentState.alphaBlendOp = VK_BLEND_OP_ADD;
	pipelineColorBlendAttachmentState.colorWriteMask = VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT;

	VkPipelineColorBlendStateCreateInfo pipelineColorBlendStateCreateInfo{};

	pipelineColorBlendStateCreateInfo.sType = VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO;
	pipelineColorBlendStateCreateInfo.pNext = nullptr;
	pipelineColorBlendStateCreateInfo.flags = 0;
	pipelineColorBlendStateCreateInfo.attachmentCount = 1;
	pipelineColorBlendStateCreateInfo.pAttachments = &pipelineColorBlendAttachmentState;
	pipelineColorBlendStateCreateInfo.logicOpEnable = VK_FALSE;
	pipelineColorBlendStateCreateInfo.logicOp = VK_LOGIC_OP_NO_OP;
	pipelineColorBlendStateCreateInfo.blendConstants[0] = 0.0f;
	pipelineColorBlendStateCreateInfo.blendConstants[1] = 0.0f;
	pipelineColorBlendStateCreateInfo.blendConstants[2] = 0.0f;
	pipelineColorBlendStateCreateInfo.blendConstants[3] = 0.0f;

    VkDescriptorSetLayoutBinding setLayoutBinding;
    setLayoutBinding.binding = 0;
    setLayoutBinding.descriptorCount = 1;
    setLayoutBinding.descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER_DYNAMIC;
    setLayoutBinding.pImmutableSamplers = NULL;
    setLayoutBinding.stageFlags = VK_SHADER_STAGE_COMPUTE_BIT;

    VkDescriptorSetLayoutCreateInfo setLayoutCreateInfo {};
    setLayoutCreateInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO;
    setLayoutCreateInfo.pNext = NULL;
    setLayoutCreateInfo.bindingCount = 1;
    setLayoutCreateInfo.pBindings = &setLayoutBinding;

    VkDescriptorSetLayout setLayout;
    vkCreateDescriptorSetLayout(device_, &setLayoutCreateInfo, NULL, &setLayout);

    VkPipelineLayoutCreateInfo pipelineLayoutCreateInfo{};
	pipelineLayoutCreateInfo.sType = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO;
	pipelineLayoutCreateInfo.pNext = nullptr;
	pipelineLayoutCreateInfo.flags = 0;
	pipelineLayoutCreateInfo.setLayoutCount = 1;
	pipelineLayoutCreateInfo.pSetLayouts = &setLayout;
	pipelineLayoutCreateInfo.pushConstantRangeCount = 0;
	pipelineLayoutCreateInfo.pPushConstantRanges = nullptr;

	if (vkCreatePipelineLayout(device_, &pipelineLayoutCreateInfo, nullptr, &pipelineLayout) != VK_SUCCESS)
		throw std::runtime_error("error kreating doitchland huyna");

    VkDescriptorPoolSize descriptorPoolSize {};
    descriptorPoolSize.descriptorCount = 1;
    descriptorPoolSize.type = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER_DYNAMIC;

    VkDescriptorPoolCreateInfo descriptorPoolCreateInfo {};
    descriptorPoolCreateInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
    descriptorPoolCreateInfo.maxSets = swapchainImages_.size();
    descriptorPoolCreateInfo.poolSizeCount = 1;
    descriptorPoolCreateInfo.pPoolSizes = &descriptorPoolSize;

    VkDescriptorPool descriptorPool;
    assert(VK_SUCCESS == vkCreateDescriptorPool(device_, &descriptorPoolCreateInfo, nullptr, &descriptorPool));

    std::vector<VkDescriptorSetLayout> layouts(swapchainImages_.size(), setLayout);
    VkDescriptorSetAllocateInfo descriptorSetAllocateInfo {};
    descriptorSetAllocateInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;
    descriptorSetAllocateInfo.descriptorPool = descriptorPool;
    descriptorSetAllocateInfo.descriptorSetCount = layouts.size();
    descriptorSetAllocateInfo.pSetLayouts = layouts.data();

    std::vector<VkDescriptorSet> descriptorSets(layouts.size());
    assert(VK_SUCCESS == vkAllocateDescriptorSets(device_, &descriptorSetAllocateInfo, descriptorSets.data()));

    for (auto &set: descriptorSets) {
        VkDescriptorBufferInfo bufferInfo {};
        bufferInfo.buffer = vertexBuffer;
        bufferInfo.offset = 0;
        bufferInfo.range = VK_WHOLE_SIZE;

        VkWriteDescriptorSet descriptorWrite {};
        descriptorWrite.sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
        descriptorWrite.dstSet = set;
        descriptorWrite.dstBinding = 0;
        descriptorWrite.dstArrayElement = 0;
        descriptorWrite.descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER_DYNAMIC;
        descriptorWrite.descriptorCount = 1;
        descriptorWrite.pBufferInfo = &bufferInfo;
        vkUpdateDescriptorSets(device_, 1, &descriptorWrite, 0, NULL);
    }

	VkAttachmentDescription attachmentDescription;
	attachmentDescription.flags = 0;
	attachmentDescription.format = surfaceFormatKhr.format;
	attachmentDescription.samples = VK_SAMPLE_COUNT_1_BIT;
	attachmentDescription.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
	attachmentDescription.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
	attachmentDescription.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
	attachmentDescription.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
	attachmentDescription.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
	attachmentDescription.finalLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;

	VkAttachmentReference attachmentReference;

	attachmentReference.attachment = 0;
	attachmentReference.layout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;

	VkSubpassDescription subpassDescription;

	subpassDescription.flags = 0;
	subpassDescription.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
	subpassDescription.inputAttachmentCount = 0;
	subpassDescription.pInputAttachments = nullptr;
	subpassDescription.colorAttachmentCount = 1;
	subpassDescription.pColorAttachments = &attachmentReference;
	subpassDescription.pResolveAttachments = nullptr;
	subpassDescription.pDepthStencilAttachment = nullptr;
	subpassDescription.preserveAttachmentCount = 0;
	subpassDescription.pPreserveAttachments = nullptr;

	VkSubpassDependency subpassDependency;

	subpassDependency.srcSubpass = VK_SUBPASS_EXTERNAL;
	subpassDependency.dstSubpass = 0;
	subpassDependency.srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
	subpassDependency.dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
	subpassDependency.srcAccessMask = 0;
	subpassDependency.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_READ_BIT | VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
	subpassDependency.dependencyFlags = 0;

	VkRenderPassCreateInfo renderPassCreateInfo{};

	renderPassCreateInfo.sType = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO;
	renderPassCreateInfo.pNext = nullptr;
	renderPassCreateInfo.flags = 0;
	renderPassCreateInfo.attachmentCount = 1;
	renderPassCreateInfo.pAttachments = &attachmentDescription;
	renderPassCreateInfo.subpassCount = 1;
	renderPassCreateInfo.pSubpasses = &subpassDescription;
	renderPassCreateInfo.dependencyCount = 1;
	renderPassCreateInfo.pDependencies = &subpassDependency;

	if (vkCreateRenderPass(device_, &renderPassCreateInfo, nullptr, &renderPass) != VK_SUCCESS)
		throw std::runtime_error("HUYNA YEBANAYA TUT");

	VkPipelineCacheCreateInfo pipelineCacheCreateInfo{};

	pipelineCacheCreateInfo.flags = 0;
	pipelineCacheCreateInfo.pNext = nullptr;
	pipelineCacheCreateInfo.sType = VK_STRUCTURE_TYPE_PIPELINE_CACHE_CREATE_INFO;
	pipelineCacheCreateInfo.initialDataSize = 0;
	pipelineCacheCreateInfo.pInitialData = nullptr;

	if (vkCreatePipelineCache(device_, &pipelineCacheCreateInfo, nullptr, &pipelineCache) != VK_SUCCESS)
		throw std::runtime_error("TOHA ISPRAVIT");

	VkComputePipelineCreateInfo computePipelineCreateInfo{};

	computePipelineCreateInfo.sType = VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO;
	computePipelineCreateInfo.pNext = nullptr;
	computePipelineCreateInfo.flags = VK_PIPELINE_CREATE_ALLOW_DERIVATIVES_BIT;
	computePipelineCreateInfo.stage = pipelineShaderStageCreateInfoComp;
	computePipelineCreateInfo.layout = pipelineLayout;
	computePipelineCreateInfo.basePipelineHandle = VK_NULL_HANDLE;
	computePipelineCreateInfo.basePipelineIndex = -1;

	if (vkCreateComputePipelines(device_, pipelineCache, 1, &computePipelineCreateInfo, nullptr, &computePipeline) != VK_SUCCESS)
		throw std::runtime_error("HUY");

	VkGraphicsPipelineCreateInfo graphicsPipelineCreateInfo{};

	graphicsPipelineCreateInfo.sType = VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO;
	graphicsPipelineCreateInfo.pNext = nullptr;
	graphicsPipelineCreateInfo.flags = VK_PIPELINE_CREATE_DERIVATIVE_BIT;
	graphicsPipelineCreateInfo.stageCount = 2;
	graphicsPipelineCreateInfo.pStages = shaderStagesInfo;
	graphicsPipelineCreateInfo.pVertexInputState = &piplineVertexInputStageCreateInfo;
	graphicsPipelineCreateInfo.pInputAssemblyState = &piplineInputAssamblyStateInfo;
	graphicsPipelineCreateInfo.pTessellationState = nullptr;
	graphicsPipelineCreateInfo.pViewportState = &pipelineViewpotrStateCreateInfo;
	graphicsPipelineCreateInfo.pRasterizationState = &pipelineRasterizationStateCreateInfo;
	graphicsPipelineCreateInfo.pMultisampleState = &pipelineMultisampleStateCreateInfo;
	graphicsPipelineCreateInfo.pDepthStencilState = nullptr;
	graphicsPipelineCreateInfo.pColorBlendState = &pipelineColorBlendStateCreateInfo;
	graphicsPipelineCreateInfo.pDynamicState = nullptr;
	graphicsPipelineCreateInfo.layout = pipelineLayout;
	graphicsPipelineCreateInfo.renderPass = renderPass;
	graphicsPipelineCreateInfo.subpass = 0;
	graphicsPipelineCreateInfo.basePipelineHandle = computePipeline;
	graphicsPipelineCreateInfo.basePipelineIndex = -1;

	if (vkCreateGraphicsPipelines(device_, pipelineCache, 1, &graphicsPipelineCreateInfo, nullptr, &graphicsPipeline) != VK_SUCCESS)
		throw std::runtime_error("SASAMBS");

	frameBuffers.resize(swapchainImages_.size());

	for (unsigned int i = 0; i < swapchainImages_.size(); i++) {
		std::vector<VkFramebufferCreateInfo> framebufferCreateInfo(swapchainImages_.size());

		framebufferCreateInfo[i].sType = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO;
		framebufferCreateInfo[i].pNext = nullptr;
		framebufferCreateInfo[i].flags = 0;
		framebufferCreateInfo[i].renderPass = renderPass;
		framebufferCreateInfo[i].attachmentCount = 1;
		framebufferCreateInfo[i].pAttachments = &imageViews_.data()[i];
		framebufferCreateInfo[i].width =  (uint32_t)viewport.width;
		framebufferCreateInfo[i].height = (uint32_t)viewport.height;
		framebufferCreateInfo[i].layers = 1;

		if (vkCreateFramebuffer(device_, &framebufferCreateInfo[i], nullptr, &frameBuffers.data()[i]) != VK_SUCCESS)
			throw std::runtime_error("BORIS NE LOH");
	}

	VkCommandPoolCreateInfo commandPoolCreateInfo{};
	commandPoolCreateInfo.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
	commandPoolCreateInfo.queueFamilyIndex = queue_.iQueueFamily;

	commandPoolCreateInfo.pNext = nullptr;
	commandPoolCreateInfo.flags = 0;

	if (vkCreateCommandPool(device_, &commandPoolCreateInfo, nullptr, &queue_.hCommandPool) != VK_SUCCESS)
		throw std::runtime_error("Error creating command pool");

	commandBuffers_.resize(swapchainImages_.size());

	VkCommandBufferAllocateInfo commandBufferAllocateInfo{};
	commandBufferAllocateInfo.pNext = nullptr;
	commandBufferAllocateInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
	commandBufferAllocateInfo.commandPool = queue_.hCommandPool;
	commandBufferAllocateInfo.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
	commandBufferAllocateInfo.commandBufferCount = (unsigned int)commandBuffers_.size();

	if (vkAllocateCommandBuffers(device_, &commandBufferAllocateInfo, commandBuffers_.data()) != VK_SUCCESS)
		throw std::runtime_error("Error creating command buffers");

	VkSemaphoreCreateInfo semaphoreCreateInfo{};
	semaphoreCreateInfo.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;

	if (vkCreateSemaphore(device_, &semaphoreCreateInfo, nullptr, &semaphoreImageAvailable) != VK_SUCCESS ||
		vkCreateSemaphore(device_, &semaphoreCreateInfo, nullptr, &semaphoreRenderingFinished) != VK_SUCCESS)
		throw std::runtime_error("An error in the 'vkCreateSemaphore' function!");

	VkCommandBufferBeginInfo commandBufferBeginInfo{};
	commandBufferBeginInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
	commandBufferBeginInfo.flags = VK_COMMAND_BUFFER_USAGE_SIMULTANEOUS_USE_BIT;
	commandBufferBeginInfo.pNext = nullptr;
	commandBufferBeginInfo.pInheritanceInfo = nullptr;

	for (unsigned int i = 0; i < swapchainImages_.size(); i++)
	{
		if (vkBeginCommandBuffer(commandBuffers_.data()[i], &commandBufferBeginInfo) != VK_SUCCESS)
			throw std::runtime_error("AZINO777");

		VkDeviceSize offsets[] = { 0 };

		VkRenderPassBeginInfo renderPassBeginInfo{};
		renderPassBeginInfo.sType = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO;
		renderPassBeginInfo.pNext = nullptr;
		renderPassBeginInfo.renderPass = renderPass;
		renderPassBeginInfo.framebuffer = frameBuffers.data()[i];
		renderPassBeginInfo.renderArea.offset = { 0, 0 };
		renderPassBeginInfo.renderArea.extent = { (uint32_t)viewport.width, (uint32_t)viewport.height };

		VkClearValue clearValue = { 0.0f, 0.0f, 0.0f, 1.0f };

		renderPassBeginInfo.clearValueCount = 1;
		renderPassBeginInfo.pClearValues = &clearValue;

        vkCmdBindPipeline(commandBuffers_.data()[i], VK_PIPELINE_BIND_POINT_COMPUTE, computePipeline);
        uint32_t dynamicOffsets[] = { 0 };
        vkCmdBindDescriptorSets(commandBuffers_.data()[i], VK_PIPELINE_BIND_POINT_COMPUTE,
                                pipelineLayout, 0, 1, &descriptorSets[i], 1, dynamicOffsets);
		vkCmdDispatch(commandBuffers_[i], verticesPositions.size() / 50, 1, 1);

		vkCmdBeginRenderPass(commandBuffers_.data()[i], &renderPassBeginInfo, VK_SUBPASS_CONTENTS_INLINE);
        vkCmdBindPipeline(commandBuffers_.data()[i], VK_PIPELINE_BIND_POINT_GRAPHICS, graphicsPipeline);
        vkCmdBindVertexBuffers(commandBuffers_.data()[i], 0, 1, &vertexBuffer, offsets);
		vkCmdDraw(commandBuffers_.data()[i], verticesPositions.size(), 1, 0, 0);
		vkCmdEndRenderPass(commandBuffers_.data()[i]);

		if (vkEndCommandBuffer(commandBuffers_.data()[i]) != VK_SUCCESS)
			throw std::runtime_error("JOYKAZINO");
	}

    return true;
}

VulkanRender::~VulkanRender()
{
	if (vertexBufferDeviceMemory != VK_NULL_HANDLE)
		vkFreeMemory(device_, vertexBufferDeviceMemory, nullptr);

	if (vertexBuffer != VK_NULL_HANDLE)
		vkDestroyBuffer(device_, vertexBuffer, nullptr);

	if (swapchainKhr_ != VK_NULL_HANDLE)
		vkDestroySwapchainKHR(device_, swapchainKhr_, nullptr);

	for (unsigned int i = 0; i < swapchainImages_.size(); i++)
		if (commandBuffers_.data()[i] != VK_NULL_HANDLE)
			vkFreeCommandBuffers(device_, queue_.hCommandPool, 1, &commandBuffers_.data()[i]);

    for (auto &curComBuf: commandBuffers_)
        if (curComBuf != VK_NULL_HANDLE)
		    vkFreeCommandBuffers(device_, queue_.hCommandPool, 1u, &curComBuf);

	if (queue_.hCommandPool != VK_NULL_HANDLE)
		vkDestroyCommandPool(device_, queue_.hCommandPool, nullptr);

	if (graphicsPipeline != VK_NULL_HANDLE)
		vkDestroyPipeline(device_, graphicsPipeline, nullptr);

	if (renderPass != VK_NULL_HANDLE)
		vkDestroyRenderPass(device_, renderPass, nullptr);

	if (pipelineLayout != VK_NULL_HANDLE)
		vkDestroyPipelineLayout(device_, pipelineLayout, nullptr);

	if (semaphoreImageAvailable != VK_NULL_HANDLE)
		vkDestroySemaphore(device_, semaphoreImageAvailable, nullptr);

	if (semaphoreRenderingFinished != VK_NULL_HANDLE)
		vkDestroySemaphore(device_, semaphoreRenderingFinished, nullptr);

	for (unsigned int i = 0; i < swapchainImages_.size(); i++)
		if (frameBuffers.data()[i] != VK_NULL_HANDLE)
			vkDestroyFramebuffer(device_, frameBuffers.data()[i], nullptr);

	if (shaderModuleFrag != VK_NULL_HANDLE)
		vkDestroyShaderModule(device_, shaderModuleFrag, nullptr);

	if (shaderModuleVert != VK_NULL_HANDLE)
		vkDestroyShaderModule(device_, shaderModuleVert, nullptr);

	if (device_ != VK_NULL_HANDLE)
		vkDestroyDevice(device_, nullptr);

	if (surfaceKhr_ != VK_NULL_HANDLE)
		vkDestroySurfaceKHR(instance_, surfaceKhr_, nullptr);

	if (instance_ != VK_NULL_HANDLE)
		vkDestroyInstance(instance_, nullptr);
}

void VulkanRender::draw()
{
	/*(for (size_t i = 0; i < verticesPositions.size(); i++)
		verticesPositions[i] = glm::vec2(2.0f * ((rand() % 10000) / 10000.0f - 0.5f), 2.0f * ((rand() % 10000) / 10000.0f - 0.5f));

	void* rawData;
	vkMapMemory(device_, vertexBufferDeviceMemory, 0, bufferCreateInfo.size, 0, &rawData);
	memcpy(rawData, verticesPositions.data(), bufferCreateInfo.size);
	vkUnmapMemory(device_, vertexBufferDeviceMemory);*/

	unsigned int acquireNextImage;
	if (vkAcquireNextImageKHR(device_, swapchainKhr_, UINT64_MAX, semaphoreImageAvailable, VK_NULL_HANDLE, &acquireNextImage) != VK_SUCCESS)
		throw std::runtime_error("An error in the 'vkAcquireNextImageKHR' function!");

	VkPipelineStageFlags pipelineStageFlags = VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT;

	VkSubmitInfo submitInfo{};
	submitInfo.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
	submitInfo.pNext = nullptr;
	submitInfo.waitSemaphoreCount = 1;
	submitInfo.pWaitSemaphores = &semaphoreImageAvailable;
	submitInfo.pWaitDstStageMask = &pipelineStageFlags;
	submitInfo.commandBufferCount = 1;
	submitInfo.pCommandBuffers = &commandBuffers_[acquireNextImage];
	submitInfo.signalSemaphoreCount = 1;
	submitInfo.pSignalSemaphores = &semaphoreRenderingFinished;

	if (vkQueueSubmit(queue_.hQueue, 1, &submitInfo, VK_NULL_HANDLE) != VK_SUCCESS)
		throw std::runtime_error("An error in the 'vkQueueSubmit' function!");

	VkPresentInfoKHR presentInfoKhr{};
	presentInfoKhr.sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR;
	presentInfoKhr.waitSemaphoreCount = 1;
	presentInfoKhr.pWaitSemaphores = &semaphoreRenderingFinished;
	presentInfoKhr.swapchainCount = 1;
	presentInfoKhr.pSwapchains = &swapchainKhr_;
	presentInfoKhr.pImageIndices = &acquireNextImage;

	if (vkQueuePresentKHR(queue_.hQueue, &presentInfoKhr) != VK_SUCCESS)
		throw std::runtime_error("An error in the 'vkQueuePresentKHR' function!");
}
