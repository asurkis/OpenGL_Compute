#include "stdafx.h"

Vertex::Vertex(glm::vec2 vertexPosition_)
{
	vertexPosition = vertexPosition_;
}


Vertex::~Vertex()
{
}

VkVertexInputBindingDescription Vertex::getVkVertexInputBindingDescription() {
	
	VkVertexInputBindingDescription vertexInputBindingDescription{};
	vertexInputBindingDescription.binding = 0;
	vertexInputBindingDescription.stride = sizeof(Vertex);
	vertexInputBindingDescription.inputRate = VK_VERTEX_INPUT_RATE_VERTEX;

	return vertexInputBindingDescription;
}

std::vector<VkVertexInputAttributeDescription> Vertex::getVkVertexInputAttributeDescription() {
	std::vector<VkVertexInputAttributeDescription> vertexInputAttributeDescription(1);

	vertexInputAttributeDescription.data()[0].binding = 0;
	vertexInputAttributeDescription.data()[0].offset = offsetof(Vertex, vertexPosition);
	vertexInputAttributeDescription.data()[0].format = VK_FORMAT_R32G32_SFLOAT;
	vertexInputAttributeDescription.data()[0].location = 0;

	return vertexInputAttributeDescription;
}
